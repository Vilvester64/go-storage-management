# Storage Management API

Sistem manajemen file berbasis web yang aman, efisien, dan skalabel. Dibangun menggunakan arsitektur Headless REST API dengan Golang (Gin) dan MySQL.

## Fitur Utama (MVP)
*   **Autentikasi & Otorisasi:** Sistem Login dan Register yang aman menggunakan JSON Web Token (JWT) dan *password hashing* dengan bcrypt.
*   **CRUD File:** Mengunggah file tunggal, mengunduh file, mengganti nama, dan manajemen file dasar.
*   **Keamanan Terjamin:** Perlindungan dari eksploitasi *Path Traversal*, validasi MIME *type*, dan pembatasan CORS (Cross-Origin Resource Sharing).
*   **Soft Delete (Trash Bin):** Implementasi GORM untuk penghapusan file sementara (ke tempat sampah) tanpa langsung menghapus data fisik (menghindari kehilangan data akibat ketidaksengajaan).
*   **Manajemen Database Otomatis:** Migrasi skema database yang dikelola secara rapi menggunakan GORM ORM.

## Tech Stack Backend
*   **Bahasa:** Golang (Go)
*   **Web Framework / Router:** Gin (Performa tinggi, manajemen *middleware* yang sangat baik untuk I/O file)
*   **Database:** MySQL (Bisa dijalankan di lingkungan lokal via Laragon)
*   **ORM:** GORM
*   **File Storage:** Local File System (Tahap Awal) -> MinIO/AWS S3 (Masa Depan)

## Struktur Repositori (Clean Architecture)
```text
storage-manager-api/
├── cmd/api/          # Entry point (main.go)
├── internal/         # Kode inti aplikasi (handlers, models, repository, services)
├── docs/             # Dokumentasi proyek (PRD, Design, API Reference, dll)
├── uploads/          # Folder lokal untuk penyimpanan file fisik (diabaikan oleh Git)
└── .env              # Variabel lingkungan (Konfigurasi DB, JWT Secret)
```

## Prasyarat Lingkungan (Prerequisites)
Pastikan alat-alat berikut telah terpasang di sistem operasi Anda:
*   [Golang](https://golang.org/dl/) (v1.20 atau lebih baru)
*   MySQL Server (Direkomendasikan menggunakan [Laragon](https://laragon.org/) untuk pengguna Windows)
*   [Postman](https://www.postman.com/) (Untuk pengujian endpoint API)
*   [Git](https://git-scm.com/)

## Instalasi & Menjalankan Aplikasi Secara Lokal

1.  **Kloning repositori:**
    ```bash
    git clone https://github.com/Vilvester64/storage-manager-api.git
    cd storage-manager-api
    ```
2.  **Siapkan Database:**
    Buka Laragon, mulai layanan MySQL, lalu buat database baru bernama `storage_db` (bisa menggunakan aplikasi *client* seperti HeidiSQL bawaan Laragon atau via terminal).
3.  **Konfigurasi Environment:**
    Salin file `.env.example` (jika ada) atau buat file `.env` baru di *root* proyek. Sesuaikan konfigurasinya (lihat `docs/env_setup.md`).
4.  **Unduh Dependensi:**
    ```bash
    go mod download
    ```
5.  **Jalankan Server API:**
    ```bash
    go run ./cmd/api/main.go
    ```
    Server akan mulai berjalan secara default di `http://localhost:8080`.

## Dokumentasi Tambahan
Silakan merujuk ke folder `docs/` untuk panduan pengembangan yang lebih komprehensif:
*   `docs/api_reference.md`: Daftar *endpoint*, format *request*, dan contoh *response*.
*   `docs/design.md`: Arsitektur sistem dan skema database.
*   `docs/workflow.md`: Alur kerja autentikasi dan transfer I/O file.
*   `docs/env_setup.md`: Panduan konfigurasi `.env`.

---
*Dibuat oleh [Fairus Syahdilla Rabbani]*
